class Censista{
    constructor(){
       this.nombre;
       this.nombreUsuario;
       this.contraseña;
    }        
}



