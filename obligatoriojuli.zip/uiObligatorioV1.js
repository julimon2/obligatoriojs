function eventos() {
    document.querySelector("#btnRegistrarCensista").addEventListener("click", registrarCensista);
    document.querySelector("#btnLogIn").addEventListener("click",logIn);
    /*document.querySelector("#btnEjercicio123").addEventListener("click", ejercicio1Tabla2);
    document.querySelector("#btnEjercicio2").addEventListener("click", ejercicio2Guardar);
    document.querySelector("#btnEjercicio22").addEventListener("click", ejercicio2Tabla1);
    document.querySelector("#btnEjercicio24").addEventListener("click", ejercicio2buscar);
    document.querySelector("#btnEjercicio4").addEventListener("click", ejercicio4Guardar);
    document.querySelector("#btnEjercicio41").addEventListener("click", ejercicio4Tabla1);
    document.querySelector("#btnEjercicio42").addEventListener("click", ejercicio4mostrar);
    document.querySelector("#btnEjercicio5").addEventListener("click", ejercicio5Guardar);
    document.querySelector("#btnEjercicio52").addEventListener("click", ejercicio5test);
    document.querySelector("#btnMostrar").addEventListener("click", mostrarVentasUI);
    document.querySelector("#btnTestMostrarTotalVentas").addEventListener("click", testMostrarTotalVentasUI);
    document.querySelector("#btnMostrarTablaVentasXtipo").addEventListener("click", mostrarTablaVentasXtipoUI);*/
}
eventos()

ocultarDiv("prueba2");

function registrarCensista() {
    let mensaje = "";
    let nombre = document.querySelector("#txtNombreCensista").value;
    let nombreUsuario = document.querySelector("#txtNombreDeUsuario").value;
    let contraseña = document.querySelector("#txtContraseña").value;
    if (validarIngresoAlgo(nombre) && validarIngresoAlgo(nombreUsuario) && validarIngresoAlgo(contraseña)) {
        if (!miSistema.existeNombreUsuario(nombreUsuario)) {
            if (miSistema.validarContraseña(contraseña)) {

                miSistema.guardarCensista(nombre,nombreUsuario,contraseña); //agregar idúnico
                

                mensaje = "Se registró correctamente"; //se puede eliminar
                ocultarDiv("divFormRegistro") //falta ver qué hacemos después de cargarlo
                mostrarDiv("divLogin");// eliminar form registro y mostrar form log in, dejar siempre arriba el menú
                

            } else {
                mensaje = "La contraseña no cumple con los requisitos"
            }          
        } else {
            mensaje = `El usuario ya existe.`;
        }
    } else {
        mensaje = `Debe completar todos los campos`;
    }
    document.querySelector("#pMostrarRegistroCensista").innerHTML = mensaje;
}

function logIn() {
    let mensaje = "";
    let nombreUsuario = document.querySelector("#txtNombreDeUsuarioLogIn").value;
    let contraseña = document.querySelector("#txtContraseñaLogIn").value;
    if (validarIngresoAlgo(nombreUsuario) && validarIngresoAlgo(contraseña)) {
        if (miSistema.login(nombreUsuario,contraseña)) {
            mensaje = `Inició sesión correctamente`;
            //acá se tienen que mostrar las cosas, osea que pueda hacer click en el menú y aparezca la info
        } else {
            mensaje = `Usuario o contraseña incorrecta`;
        }
    } else {
        mensaje = `Debe completar todos los campos`;
    }
    document.querySelector("#pMostrarLogInCensista").innerHTML = mensaje;
    
}

function guardarDatosCensado() {
    let mensaje = "";
    let nombre = document.querySelector("#txtNombreCensado").value;
    let apellido = document.querySelector("#txtApellidoCensado").value;
    let edad = document.querySelector("#txtEdadCensado").value;
    let cedula = document.querySelector("#txtCedulaCensado").value;
    let departamento = document.querySelector("#selDepartamentosCenso").value;
    let ocupacion = document.querySelector("#selOcupaciones").value;
    if (validarIngresoAlgo(nombre) && validarIngresoAlgo(apellido) && validarIngresoAlgo(edad) && validarIngresoAlgo(cedula)) {
        if (departamento !== "Seleccione" && ocupacion !== "Seleccione") {
            if (!isNaN(edad)) {
                let edadNro = Number(edad);
                if (edadNro >= 0 && edadNro <= 130) {
                    //me falta sacarle todos los guiones y cosas a la cédula
                    //me falta lo del digito verificador
                    //me falta una función de existeCédula
                    //después de validar todo hay que
                } else {
                    mensaje = "La edad tiene que ser entre 0 y 130"
                }

            } else {
                mensaje = "Debe ingresar un nro";
            }

        } else {
            mensaje= "Debe seleccionar una opción";
        }
        
    } else {
        mensaje = `Debe completar todos los campos`;
    }
    document.querySelector("#pMostrarFormulario").innerHTML = mensaje;
}


function cargarComboDepartamentos() {
    let lasOpciones = `<option value="Seleccione"> Seleccione departamento</option>`;
    for (let i = 0; i < departamentos.length; i++) {
        let departamentoX = departamentos[i]; 
        lasOpciones += `<option value="${departamentoX}"> ${departamentoX} </option>`;
    }
    document.querySelector("#selDepartamentosCenso").innerHTML = lasOpciones;
}
cargarComboDepartamentos()

function mostrarDiv(pDiv) {
    document.querySelector(`#${pDiv}`).style.display = "block";
}

function ocultarDiv(pDiv) {
    document.querySelector(`#${pDiv}`).style.display = "none";

}



function ejercicio1Tabla() {
    let mensaje = miSistema.obtenerTablaPersonas();
    document.querySelector("#pMostrar1").innerHTML = mensaje;
}

function ejercicio1Tabla2() {
    let mensaje = miSistema.obtenerTablaPersonas18();
    document.querySelector("#pMostrar1").innerHTML = mensaje;
}

function cargarComboGeneros() {
    let lasOpciones = `<option value=""> Seleccione Tipo </option>`;
    for (let i = 0; i < generos.length; i++) {
        let generoX = generos[i]; //es un objeto de tipo "tipo"
        //los combos y otros elementos se cargar en su value con el indentificador único.
        /*if(i === 0){

            lasOpciones += `<option value="${tipoX.tipo}" selected> ${tipoX.nombre} - ${tipoX.precio} </option>`;
        }else{*/
        lasOpciones += `<option value="${generoX}"> ${generoX} </option>`;


        // console.log(lasOpciones);
    }
    document.querySelector("#generoPelicula").innerHTML = lasOpciones;
}

cargarComboGeneros();

function ejercicio2Guardar() {
    let mensaje = "";
    let nombre = document.querySelector("#txtTexto2").value;
    let año = document.querySelector("#txtTexto22").value;
    let genero = document.querySelector("#generoPelicula").value;
    let cantidadVotantes = document.querySelector("#txtTexto23").value;
    let totalPuntos = document.querySelector("#txtTexto24").value;
    if (validarIngresoAlgo(nombre) && validarIngresoAlgo(año) && validarIngresoAlgo(genero) && validarIngresoAlgo(cantidadVotantes) && validarIngresoAlgo(totalPuntos)) {
        if (validarNroPositivo(año) && validarNroPositivo(cantidadVotantes)&& validarNroPositivo(totalPuntos)) {
            let añoNro = Number(año);
            let cantidadVotNro = Number(cantidadVotantes);
            let totalPuntosNro = Number(totalPuntos);
            if (!miSistema.existe(nombre)) {
                miSistema.guardarPelicula(nombre,añoNro,genero,cantidadVotNro,totalPuntosNro);

               mensaje = `se guardó la pelicula`;
            } else {
                mensaje = `la pelicula existe`
            /**/}

            
        } else {
            mensaje = `debe ingresar un nro en año.`;
        }
    } else {
        mensaje = `ingrese cantidad y selecione tipo`;
    }
    document.querySelector("#pMostrar2").innerHTML = mensaje;
}

function ejercicio2Tabla1() {
    let mensaje = miSistema.obtenerTablaPromedio();
    document.querySelector("#pMostrar2").innerHTML = mensaje;
}

function ejercicio2buscar() {
    let mensaje = "";
    let nombre = document.querySelector("#txtTexto25").value;
    if (validarIngresoAlgo(nombre)) {
        if (miSistema.existe(nombre)) {
            mensaje = miSistema.mostrarPelicula(nombre);
        } else {
            mensaje = "el objeto no existe"
        }
    
    } else {
        mensaje = `debe ingresar algo`;
    }
    document.querySelector("#pMostrar2").innerHTML = mensaje;
}

function cargarComboMarcas() {
    let lasOpciones = `<option value=""> Seleccione Tipo </option>`;
    for (let i = 0; i < marcas.length; i++) {
        let marcaX = marcas[i]; //es un objeto de tipo "tipo"
        //los combos y otros elementos se cargar en su value con el indentificador único.
        /*if(i === 0){

            lasOpciones += `<option value="${tipoX.tipo}" selected> ${tipoX.nombre} - ${tipoX.precio} </option>`;
        }else{*/
        lasOpciones += `<option value="${marcaX}"> ${marcaX} </option>`;


        // console.log(lasOpciones);
    }
    document.querySelector("#marcasCelulares").innerHTML = lasOpciones;
}

cargarComboMarcas();

function ejercicio4Guardar() {
    let mensaje = "";
    let marca = document.querySelector("#marcasCelulares").value;
    let modelo = document.querySelector("#txtTexto4").value;
    let precio = document.querySelector("#txtTexto41").value;
    let cantidad = document.querySelector("#txtTexto42").value;
    if (validarIngresoAlgo(modelo)) {
        if (validarNroPositivo(precio) && validarNroPositivo(cantidad)) {
            let precioNro = Number(precio);
            let cantidadNro = Number(cantidad);

            miSistema.guardarVentaCelular(marca,modelo,precioNro,cantidadNro);

            mensaje = `se guardó la venta`;
        } else {
            mensaje = `debe ingresar un nro.`;
        }
    } else {
        mensaje = `complete los campos`;
    }
    document.querySelector("#pMostrar4").innerHTML = mensaje;
}

function ejercicio4Tabla1() {
    let mensaje = miSistema.obtenerTablaVentas();
    document.querySelector("#pMostrar4").innerHTML = mensaje;

}

function ejercicio4mostrar() {
    let mensaje = "";
    let modelo = document.querySelector("#txtTexto43").value;
    if (validarIngresoAlgo(modelo)) {
         
        mensaje = `La cantidad vendida del modelo: ${modelo} es ${miSistema.obtenerCantidadesXModelo(modelo)} `


    } else {
        mensaje = `complete los campos`;
    }
    document.querySelector("#pMostrar4").innerHTML = mensaje;
}

function cargarComboOrigen() {
    let lasOpciones = `<option value=""> Seleccione origen </option>`;
    for (let i = 0; i < origen.length; i++) {
        let origenX = origen[i]; //es un objeto de tipo "tipo"
        //los combos y otros elementos se cargar en su value con el indentificador único.
        /*if(i === 0){

            lasOpciones += `<option value="${tipoX.tipo}" selected> ${tipoX.nombre} - ${tipoX.precio} </option>`;
        }else{*/
        lasOpciones += `<option value="${origenX}"> ${origenX} </option>`;


        // console.log(lasOpciones);
    }
    document.querySelector("#origen").innerHTML = lasOpciones;
}

cargarComboOrigen();

function ejercicio5Guardar() {
    let mensaje = "";
    let origen = document.querySelector("#origen").value;
    let marca = document.querySelector("#txtTexto5").value;
    let talle = document.querySelector("#txtTexto51").value;
    let color = document.querySelector("#txtTexto52").value;
    if (validarIngresoAlgo(marca)) {
        if (validarNroPositivo(talle)) {
            let talleNro = Number(talle);
            if (talleNro >= 30 && talleNro <= 46) {
                miSistema.guardarZapato(origen,marca,talleNro,color);
                mensaje = "se guardó el zapato";
            } else {
                mensaje ="debe ingresar un talle entre 30 y 46";
            }
            

            /*if (!miSistema.existe(nombre)) {
                miSistema.guardarPelicula(nombre,añoNro,genero,cantidadVotNro,totalPuntosNro);

               mensaje = `se guardó la pelicula`;
            } else {
                mensaje = `la pelicula existe`
            }*/

            
        } else {
            mensaje = `debe ingresar un nro.`;
        }
    } else {
        mensaje = `ingrese marca`;
    }
    document.querySelector("#pMostrar5").innerHTML = mensaje;
}

function ejercicio5test() {

    let origen = document.querySelector("#origen").value;
    let mensaje = "";
    miSistema. obtenerZapato38(zapatos,origen)

    mensaje = `El ${origen} cuenta con ${contador1} de zapatos de 38 mientras `


    document.querySelector("#pMostrar5").innerHTML = mensaje;
}