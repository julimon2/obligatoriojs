let usuariosCensistas = new Array();
let departamentos = new Array("Montevideo","San José","Canelones","Maldonado","Rocha","Colonia","Flores","Florida","Lavalleja","Rio Negro","Soriano","Cerro Largo","Treinta y Tres","Durazno","Tacuarembó","Rivera","Salto","Paysandú","Artigas",)
/*let generos = new Array("comedia","drama","ciencia ficción");
let peliculas = new Array();
let marcas = new Array("Samsung","Sony","LG");
let ventasCelulares = new Array();
let origen = new Array("Importado","Nacional");
let zapatos = new Array();*/


/*let contador1 = 0;
let contador2 = 0;


function preCargaPeliculas() {
    let pelicula1 = new Pelicula();
 // el id se actuliza en el objeto.  
    pelicula1.nombre = "Hola";
    pelicula1.año = 1995;
    pelicula1.genero = "comedia";
    pelicula1.cantidadVotantes = "50";
    pelicula1.puntos = "100";
    peliculas.push(pelicula1);
}*/

class Sistema {

    constructor() {
        this.usuarioLogueado = null;
    }

    existeNombreUsuario(pNombreUsuario) {

        let existe = false;
        let i = 0;
        while (i < usuariosCensistas.length && !existe){ 
            let minusculasPnombre = pNombreUsuario.toLowerCase();
            let usuarioX = usuariosCensistas[i];
            let nombreUsuarioX = usuarioX.nombre;
            let nombreUsuarioXminu = nombreUsuarioX.toLowerCase();      
          if(nombreUsuarioXminu === minusculasPnombre){
              existe = true;
          }  
          i++;
       }
    
    
    return existe;
    
    }

    validarContraseña(pContraseña){
        let cumple = false;
        let contadorMayuscula = 0;
        let contadorMinuscula = 0;
        let contadorNumero = 0;

        for (let i = 0; i < pContraseña.length; i++) {
            let caracter = pContraseña.charAt(i);

                if (caracter === caracter.toUpperCase()) {

                    contadorMayuscula += 1;
                    
                 }

                if (caracter === caracter.toLowerCase()) {

                    contadorMinuscula += 1;
                    
                 }

                 if (!isNaN(caracter)) {

                    contadorNumero += 1;
                    
                 }

        }

        if (pContraseña.length >= 5 && contadorMayuscula > 0 && contadorMinuscula > 0 && contadorNumero > 0) {

             cumple = true;
            
        }

        
       return cumple;

    
    }

    login(pNombreUsuario, pContraseña) {
        let logIn = false;
        let usuario = this.obtenerUsuarioCensista(pNombreUsuario);
        if (usuario !== null) {
            if (usuario.contraseña === pContraseña) {
                logIn = true;
                this.usuarioLogueado = usuario;
            }
        }
        return logIn;
    }



    obtenerUsuarioCensista(pNombreUsuario) {
        let censista = null;
        let i = 0;
        while (i < usuariosCensistas.length && censista === null) {
            let usuX = usuariosCensistas[i];
            if (usuX.nombreUsuario === pNombreUsuario) {
                censista = usuX; 
            }
            i++;
        }
        return censista;
    }


    guardarCensista(pNombre, pNombreUsuario, pContraseña) { 
        let usuarioX = new Censista();     
        usuarioX.nombre = pNombre;
        usuarioX.nombreUsuario = pNombreUsuario;
        usuarioX.contraseña = pContraseña;
        usuariosCensistas.push(usuarioX);
    }








    /*obtenerTablaPersonas() {
        let miTabla = `<table border="1">`;
        miTabla += `<tr><th> Nombre</th> <th> Edad</th> <th> Nacionalidad</th></tr>`;
        for (let unaPersona of personas) {
            // miTabla += `<tr><td> ${unTipo.tipo} </td> <td> ${totalVentasXtipo}</td></tr>`;
            miTabla += `<tr><td> ${unaPersona.nombre} </td> <td> ${unaPersona.edad}</td> <td> ${unaPersona.nacionalidad}</td></tr>`;
        }
        miTabla += `</table>`;
        return miTabla;
    }

    obtenerTablaPersonas18() {
        let miTabla = `<table border="1">`;
        miTabla += `<tr><th> Nombre</th> <th> Edad</th> <th> Nacionalidad</th></tr>`;
        for (let i = 0; i < personas.length; i++) {
            let personaX = personas[i];
            if (personaX.edad > 18) {
                miTabla += `<tr><td> ${personaX.nombre} </td> <td> ${personaX.edad}</td> <td> ${personaX.nacionalidad}</td></tr>`;
            }
        
        
        /*for (let unaPersona of personas) {
            if (unaPersona.edad > 18 ) {
                 miTabla += `<tr><td> ${unaPersona.nombre} </td> <td> ${unaPersona.edad}</td> <td> ${unaPersona.nacionalidad}</td></tr>`;
            }
            // miTabla += `<tr><td> ${unTipo.tipo} </td> <td> ${totalVentasXtipo}</td></tr>`;
           
        }
        
        }
        miTabla += `</table>`;
        return miTabla;
    }

    
 
    existe(pNombre){

        let existe = false;
        let i = 0;
        while (i < peliculas.length && !existe){ 
            let peliculaX = peliculas[i]       
          if( peliculaX.nombre === pNombre){
              existe = true;
          }  
          i++;
       }
    
    
    return existe;
    
    }

    guardarPelicula(pNombre, pAño, pGenero, pVotantes, pPuntos) { //se asume llegan datos válidos
        let peliculaX = new Pelicula();
        //id queda a nivel de objeto      
        peliculaX.nombre = pNombre;
        peliculaX.año = pAño;
        peliculaX.genero = pGenero;
        peliculaX.cantidadVotantes = pVotantes;
        peliculaX.puntos = pPuntos;
        peliculas.push(peliculaX);
    }

    obtenerTablaPromedio() {
        let miTabla = `<table border="1">`;
        miTabla += `<tr><th> Nombre</th> <th> </th></tr>`;
        let promedio = 0;
        for (let i = 0; i < peliculas.length; i++) {
            let peliculaX = peliculas[i];
            promedio = peliculaX.puntos/peliculaX.cantidadVotantes;
            if (promedio > 4) {
                miTabla += `<tr><td> ${peliculaX.nombre} </td> <td> ${promedio}</td></tr>`;
            } 

        
        
        /*for (let unaPersona of personas) {
            if (unaPersona.edad > 18 ) {
                 miTabla += `<tr><td> ${unaPersona.nombre} </td> <td> ${unaPersona.edad}</td> <td> ${unaPersona.nacionalidad}</td></tr>`;
            }
            // miTabla += `<tr><td> ${unTipo.tipo} </td> <td> ${totalVentasXtipo}</td></tr>`;
           
        }
        
        }
        miTabla += `</table>`;
        return miTabla;
    }

    mostrarPelicula(pNombre){

        let mensaje = "";
        let i = 0;
        while (i < peliculas.length){ 
            let peliculaX = peliculas[i]       
          if( peliculaX.nombre === pNombre){
              mensaje = `Nombre: ${peliculaX.nombre} - Año: ${peliculaX.año} - Genero: ${peliculaX.genero} ` ;
          }  
          i++;
       }
    
    
    return mensaje;
    
    }

    guardarVentaCelular(pMarca, pModelo, pPrecio, pCantidad) { //se asume llegan datos válidos
        let ventaX = new Venta();
        //id queda a nivel de objeto      
        ventaX.marca = pMarca;
        ventaX.modelo = pModelo;
        ventaX.precio = pPrecio;
        ventaX.cantidad = pCantidad;
        ventasCelulares.push(ventaX);
    }

    obtenerTablaVentas() {
        let miTabla = `<table border="1">`;
        miTabla += `<tr><th> Marca</th> <th> Modelo</th> <th> Nro de venta</th> <th> Monto</th></tr>`;
        let sumaVentas = 0;
        for (let i = 0; i < ventasCelulares.length; i++) {
            let ventaX = ventasCelulares[i];
            sumaVentas = ventaX.cantidad * ventaX.precio;
            if (sumaVentas > 2000) {
                miTabla += `<tr><td> ${ventaX.marca} </td> <td> ${ventaX.modelo}</td> <td> ${ventaX.id}</td> <td> ${sumaVentas}</td></tr>`;
            } 

        
        
        /*for (let unaPersona of personas) {
            if (unaPersona.edad > 18 ) {
                 miTabla += `<tr><td> ${unaPersona.nombre} </td> <td> ${unaPersona.edad}</td> <td> ${unaPersona.nacionalidad}</td></tr>`;
            }
            // miTabla += `<tr><td> ${unTipo.tipo} </td> <td> ${totalVentasXtipo}</td></tr>`;
           
        }
        
        }
        miTabla += `</table>`;
        return miTabla;
    }

    obtenerCantidadesXModelo(pModelo) {
        let cantidadTotal = 0;
        for (let i = 0; i < ventasCelulares.length; i++) {
            let ventaX = ventasCelulares[i];
            if (ventaX.modelo === pModelo) {
                let cantidadXobjeto = ventaX.cantidad;
                cantidadTotal += cantidadXobjeto;
            } 
        
        }

        return cantidadTotal;
    }
    guardarZapato(pOrigen, pMarca, pTalle, pColor) { //se asume llegan datos válidos
        let zapatoX = new Zapato();
        //id queda a nivel de objeto      
        zapatoX.origen = pOrigen;
        zapatoX.marca = pMarca;
        zapatoX.talle = pTalle;
        zapatoX.color = pColor;
        zapatos.push(zapatoX);
    }

    obtenerZapato38(pZapatos,pOrigen) {
        let contador = 0;
        for (let i = 0; i <pZapatos.length; i++) {
            let zapatoX = pZapatos[i];
            if (zapatoX.talle > 38 && zapatoX.origen === pOrigen) {
                contador += 1;
            }
        
        }

        return contador;
    }

    
    obtenerZapato382(pZapatos,pOrigen1,pOrigen2) {
        for (let i = 0; i <pZapatos.length; i++) {
            let zapatoX = pZapatos[i];
            if (zapatoX.talle > 38)
                if (zapatoX.origen === pOrigen1) {
                     contador1 += 1;
                } else {
                    contador2 += 1;
                }
        
        }


    }



}*/

}


function validarIngresoAlgo(pAlgo) {
    return pAlgo.trim().length > 0;
}
function validarNroPositivo(pNro) {
    return !isNaN(pNro) && Number(pNro) >= 0;
}


let miSistema = new Sistema();

/*preCargaPeliculas();*/